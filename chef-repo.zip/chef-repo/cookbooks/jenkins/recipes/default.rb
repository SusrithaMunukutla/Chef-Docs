#
# Cookbook:: jenkins
# Recipe:: default
#
# Copyright:: 2017, The Authors, All Rights Reserved.

windows_package 'jenkins' do
     source 'https://s3-ap-southeast-1.amazonaws.com/susritha-backup/jenkins.msi'
     remote_file_attributes ({
            :path => 'C:\\jenkins\\jenkins.msi'
  })
     action :install
end

