#
# Cookbook Name:: teamcity-server
# Recipe:: default
#
# Copyright 2017, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#
windows_package 'teamcity-server' do
     source 'https://download-cf.jetbrains.com/teamcity/TeamCity-2017.1.1.exe'
     remote_file_attributes ({
            :path => 'C:\\teamcity_server\\teamcityserver.exe'
  })
   not_if{::File.exist?('C:\\teamcity_server\\teamcityserver.exe')}
     action :install
end