name 'learn_chef_iis'
maintainer 'The Authors'
maintainer_email 'you@example.com'
license 'all_rights'
description 'Installs/Configures learn_chef_iis'
long_description 'Installs/Configures learn_chef_iis'
version '0.2.0'
issues_url 'https://github.com/learn-chef/learn_chef_iis/issues' if respond_to?(:issues_url)
source_url 'https://github.com/learn-chef/learn_chef_iis' if respond_to?(:source_url)
