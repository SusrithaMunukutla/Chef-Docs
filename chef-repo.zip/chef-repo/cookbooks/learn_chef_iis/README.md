# learn_chef_iis

This basic cookbook configures IIS on Windows Server 2012 R2.
