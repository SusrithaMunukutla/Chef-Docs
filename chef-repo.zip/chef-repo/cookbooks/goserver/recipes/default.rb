#
# Cookbook Name:: goserver
# Recipe:: default
#
# Copyright 2017, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#
windows_package 'goserver' do
     source 'https://download.gocd.io/binaries/17.4.0-4892/win/go-server-17.4.0-4892-jre-64bit-setup.exe'
     remote_file_attributes ({
            :path => 'C:\\goserver\\goserver.exe'
  })
     not_if{::File.exist?('C:\\goserver\\goserver.exe')}
     action :install
end