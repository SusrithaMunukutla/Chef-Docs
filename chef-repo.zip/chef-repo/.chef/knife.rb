current_dir = File.dirname(__FILE__)
log_level                 :info
log_location              STDOUT
node_name                 "susritha"
client_key                "#{current_dir}/susritha.pem"
chef_server_url           "https://ec2-54-252-228-249.ap-southeast-2.compute.amazonaws.com/organizations/virtusa"
cookbook_path             ["#{current_dir}/../cookbooks"]